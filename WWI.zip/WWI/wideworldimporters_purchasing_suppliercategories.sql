-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: wideworldimporters
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchasing_suppliercategories`
--

DROP TABLE IF EXISTS `purchasing_suppliercategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasing_suppliercategories` (
  `SupplierCategoryID` int NOT NULL,
  `SupplierCategoryName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastEditedBy` int NOT NULL,
  `ValidFrom` datetime(6) NOT NULL,
  `ValidTo` datetime(6) NOT NULL,
  PRIMARY KEY (`SupplierCategoryID`),
  UNIQUE KEY `UQ_Purchasing_SupplierCategories_SupplierCategoryName` (`SupplierCategoryName`),
  KEY `FK_Purchasing_SupplierCategories_Application_People` (`LastEditedBy`),
  CONSTRAINT `FK_Purchasing_SupplierCategories_Application_People` FOREIGN KEY (`LastEditedBy`) REFERENCES `application_people` (`PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchasing_suppliercategories`
--

LOCK TABLES `purchasing_suppliercategories` WRITE;
/*!40000 ALTER TABLE `purchasing_suppliercategories` DISABLE KEYS */;
INSERT INTO `purchasing_suppliercategories` VALUES (1,'Other Wholesaler',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(2,'Novelty Goods Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(3,'Toy Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(4,'Clothing Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(5,'Packaging Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(6,'Courier Services Supplier',16,'2015-01-01 16:00:00.000000','9999-12-31 23:59:59.999999'),(7,'Financial Services Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(8,'Marketing Services Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(9,'Insurance Services Supplier',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999');
/*!40000 ALTER TABLE `purchasing_suppliercategories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 11:37:52
