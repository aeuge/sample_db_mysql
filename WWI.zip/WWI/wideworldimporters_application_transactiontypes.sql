-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: wideworldimporters
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_transactiontypes`
--

DROP TABLE IF EXISTS `application_transactiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_transactiontypes` (
  `TransactionTypeID` int NOT NULL,
  `TransactionTypeName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastEditedBy` int NOT NULL,
  `ValidFrom` datetime(6) NOT NULL,
  `ValidTo` datetime(6) NOT NULL,
  PRIMARY KEY (`TransactionTypeID`),
  UNIQUE KEY `UQ_Application_TransactionTypes_TransactionTypeName` (`TransactionTypeName`),
  KEY `FK_Application_TransactionTypes_Application_People` (`LastEditedBy`),
  CONSTRAINT `FK_Application_TransactionTypes_Application_People` FOREIGN KEY (`LastEditedBy`) REFERENCES `application_people` (`PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_transactiontypes`
--

LOCK TABLES `application_transactiontypes` WRITE;
/*!40000 ALTER TABLE `application_transactiontypes` DISABLE KEYS */;
INSERT INTO `application_transactiontypes` VALUES (1,'Customer Invoice',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(2,'Customer Credit Note',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(3,'Customer Payment Received',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(4,'Customer Refund',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(5,'Supplier Invoice',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(6,'Supplier Credit Note',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(7,'Supplier Payment Issued',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(8,'Supplier Refund',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(9,'Stock Transfer',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(10,'Stock Issue',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(11,'Stock Receipt',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(12,'Stock Adjustment at Stocktake',1,'2013-01-01 00:00:00.000000','9999-12-31 23:59:59.999999'),(13,'Customer Contra',9,'2016-01-01 16:05:00.000000','9999-12-31 23:59:59.999999');
/*!40000 ALTER TABLE `application_transactiontypes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 11:37:57
