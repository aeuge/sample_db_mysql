-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: wideworldimporters
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_cities_archive`
--

DROP TABLE IF EXISTS `application_cities_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_cities_archive` (
  `CityID` int NOT NULL,
  `CityName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `StateProvinceID` int NOT NULL,
  `Location` geometry DEFAULT NULL,
  `LatestRecordedPopulation` bigint DEFAULT NULL,
  `LastEditedBy` int NOT NULL,
  `ValidFrom` datetime(6) NOT NULL,
  `ValidTo` datetime(6) NOT NULL,
  KEY `ix_Cities_Archive` (`ValidFrom`,`ValidTo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_cities_archive`
--

LOCK TABLES `application_cities_archive` WRITE;
/*!40000 ALTER TABLE `application_cities_archive` DISABLE KEYS */;
INSERT INTO `application_cities_archive` VALUES (33783,'Tennessee Colony',45,_binary '\0\0\0\0\0\0\0#�����W�\�0�\�\�?@',NULL,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(13570,'Grand Coteau',19,_binary '\0\0\0\0\0\0\0�^���W�0m�\�k>@',947,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(6069,'Charleston',44,_binary '\0\0\0\0\0\0\0m�퐇0U��\�ƤA@',651,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(21711,'Medway',22,_binary '\0\0\0\0\0\0\0\Z_\��c\�Q���vS%E@',NULL,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(13998,'Greenwood',24,_binary '\0\0\0\0\0\0\0��3icW��\�ǂuF@',688,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(37232,'Williams Creek',15,_binary '\0\0\0\0\0\0\0�\����U���ch+�C@',407,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(11557,'Finger',44,_binary '\0\0\0\0\0\0\0.t%U&V�c�rs\�A@',298,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(6817,'Cliffside',34,_binary '\0\0\0\0\0\0\0�\�D\�DqT��|�A@',611,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(35386,'Villa Heights',49,_binary '\0\0\0\0\0\0\0[\��\��S�{CYB@',717,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(16111,'Hubbard',24,_binary '\0\0\0\0\0\0\0m3���W���\\�kG@',NULL,1,'2013-01-01 00:00:00.000000','2013-07-01 16:00:00.000000'),(14966,'Hayden',32,_binary '\0\0\0\0\0\0\0\�\n~b\�Y��;C���A@',NULL,1,'2013-01-01 00:00:00.000000','2014-07-01 16:00:00.000000'),(30385,'San Isidro',40,_binary '\0\0\0\0\0\0\0\Z�W�xP��Led2@',6828,1,'2013-01-01 00:00:00.000000','2014-07-01 16:00:00.000000'),(37091,'Whiting',47,_binary '\0\0\0\0\0\0\0p��<\�LR�H\�e\�\�E@',NULL,1,'2013-01-01 00:00:00.000000','2014-07-01 16:00:00.000000'),(36965,'White Hall',4,_binary '\0\0\0\0\0\0\0\�l��\�W�G\��#A@',5526,1,'2013-01-01 00:00:00.000000','2014-07-01 16:00:00.000000'),(37136,'Wickersham',50,_binary '\0\0\0\0\0\0\0�\����^�\�ݑ�\�SH@',NULL,1,'2013-01-01 00:00:00.000000','2014-07-01 16:00:00.000000'),(24452,'Norborne',26,_binary '\0\0\0\0\0\0\0���#[kW�\�>\�޸�C@',708,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(18834,'Laupahoehoe',12,_binary '\0\0\0\0\0\0\0j�WV�gc���[�\��3@',581,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(9908,'East Smithfield',39,_binary '\0\0\0\0\0\0\0\�@YB(S�#)��\�D@',NULL,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(24608,'North Granby',7,_binary '\0\0\0\0\0\0\0$*T75R�R#�z�D@',1944,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(5368,'Carlton',17,_binary '\0\0\0\0\0\0\0@&c\�RX�j���WC@',42,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(34934,'Urbancrest',36,_binary '\0\0\0\0\0\0\0�N\0�\�T�\�\�Y\��C@',960,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(32517,'Springville',25,_binary '\0\0\0\0\0\0\0\�ձ��FV�m���A@',NULL,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(11095,'Fairfax',37,_binary '\0\0\0\0\0\0\0\�XA�.X�(�\�IB@',1380,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(21614,'McWhorter',51,_binary '\0\0\0\0\0\0\0mD\�T�P$N\�K�C@',NULL,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(33997,'Throop',33,_binary '\0\0\0\0\0\0\0 ���$S��\�C\�|E@',NULL,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(27500,'Pondosa',38,_binary '\0\0\0\0\0\0\06p�0\"i]�!���F@',NULL,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(164,'Adrian',24,_binary '\0\0\0\0\0\0\0�30��W��Gb�F\�E@',1209,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000'),(28862,'Richvale',5,_binary '\0\0\0\0\0\0\0\�� �o^�!\n�4�C@',244,1,'2013-01-01 00:00:00.000000','2015-07-01 16:00:00.000000');
/*!40000 ALTER TABLE `application_cities_archive` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 11:38:43
