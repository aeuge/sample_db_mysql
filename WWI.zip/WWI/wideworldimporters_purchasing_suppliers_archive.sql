-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: wideworldimporters
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchasing_suppliers_archive`
--

DROP TABLE IF EXISTS `purchasing_suppliers_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasing_suppliers_archive` (
  `SupplierID` int NOT NULL,
  `SupplierName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `SupplierCategoryID` int NOT NULL,
  `PrimaryContactPersonID` int NOT NULL,
  `AlternateContactPersonID` int NOT NULL,
  `DeliveryMethodID` int DEFAULT NULL,
  `DeliveryCityID` int NOT NULL,
  `PostalCityID` int NOT NULL,
  `SupplierReference` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountBranch` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountCode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankInternationalCode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PaymentDays` int NOT NULL,
  `InternalComments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `FaxNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `WebsiteURL` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DeliveryAddressLine1` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DeliveryAddressLine2` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `DeliveryPostalCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DeliveryLocation` geometry DEFAULT NULL,
  `PostalAddressLine1` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PostalAddressLine2` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PostalPostalCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastEditedBy` int NOT NULL,
  `ValidFrom` datetime(6) NOT NULL,
  `ValidTo` datetime(6) NOT NULL,
  KEY `ix_Suppliers_Archive` (`ValidFrom`,`ValidTo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchasing_suppliers_archive`
--

LOCK TABLES `purchasing_suppliers_archive` WRITE;
/*!40000 ALTER TABLE `purchasing_suppliers_archive` DISABLE KEYS */;
INSERT INTO `purchasing_suppliers_archive` VALUES (1,'A Datum Corporation',2,21,22,7,38171,38171,'AA20384','A Datum Corporation','Woodgrove Bank Zionsville','356981','8575824136','25986',14,NULL,'(847) 555-0100','(847) 555-0101','http://www.adatum.com','Suite 10','183838 Southwest Boulevard','46077',NULL,'PO Box 1039','Surrey','46077',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(13,'Woodgrove Bank',7,45,46,NULL,30378,30378,'028034202','Woodgrove Bank','Woodgrove Bank San Francisco','325698','2147825698','65893',7,'Only speak to Donald if Hubert really is not available','(415) 555-0103','(415) 555-0107','http://www.woodgrovebank.com','Level 3','8488 Vienna Boulevard','94101',NULL,'PO Box 2390','Canterbury','94101',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(3,'Consolidated Messenger',6,25,26,NULL,30378,30378,'209340283','Consolidated Messenger','Woodgrove Bank San Francisco','354269','3254872158','45698',30,NULL,'(415) 555-0100','(415) 555-0101','http://www.consolidatedmessenger.com','','894 Market Day Street','94101',NULL,'PO Box 1014','West Mont','94101',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(7,'Litware, Inc.',5,33,34,2,22602,22602,'BC0280982','Litware Inc','Woodgrove Bank Mokelumne Hill','358769','3256896325','21445',30,NULL,'(209) 555-0108','(209) 555-0104','http://www.litwareinc.com','Level 3','19 Le Church Street','95245',NULL,'PO Box 20290','Jackson','95245',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(6,'Humongous Insurance',9,31,32,NULL,18656,18656,'082420938','Humongous Insurance','Woodgrove Bank Lancing','325001','2569874521','32569',14,NULL,'(423) 555-0105','(423) 555-0100','http://www.humongousinsurance.com','','9893 Mount Norris Road','37770',NULL,'PO Box 94829','Boxville','37770',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(5,'Graphic Design Institute',2,29,30,10,18634,18634,'08803922','Graphic Design Institute','Woodgrove Bank Lanagan','563215','1025869354','32587',14,NULL,'(406) 555-0105','(406) 555-0106','http://www.graphicdesigninstitute.com','','45th Street','64847',NULL,'PO Box 393','Willow','64847',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(4,'Fabrikam, Inc.',4,27,28,7,18557,18557,'293092','Fabrikam Inc','Woodgrove Bank Lakeview Heights','789568','4125863879','12546',30,NULL,'(203) 555-0104','(203) 555-0108','http://www.fabrikam.com','Level 2','393999 Woodberg Road','40351',NULL,'PO Box 301','Eaglemont','40351',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(12,'The Phone Company',2,43,44,7,17346,17346,'237408032','The Phone Company','Woodgrove Bank Karlstad','214568','7896236589','25478',30,NULL,'(218) 555-0105','(218) 555-0105','http://www.thephone-company.com','Level 83','339 Toorak Road','56732',NULL,'PO Box 3837','Ferny Wood','56732',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(11,'Trey Research',8,41,42,NULL,17277,17277,'082304822','Trey Research','Woodgrove Bank Kadoka','658968','1254785321','56958',7,NULL,'(605) 555-0103','(605) 555-0101','http://www.treyresearch.net','Level 43','9401 Polar Avenue','57543',NULL,'PO  Box 595','Port Fairy','57543',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(8,'Lucerne Publishing',2,35,36,10,17161,17161,'JQ082304802','Lucerne Publishing','Woodgrove Bank Jonesborough','654789','3254123658','21569',30,NULL,'(423) 555-0103','(423) 555-0105','http://www.lucernepublishing.com','Suite 34','949482 Miller Boulevard','37659',NULL,'PO Box 8747','Westerfold','37659',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(2,'Contoso, Ltd.',2,23,24,9,13870,13870,'B2084020','Contoso Ltd','Woodgrove Bank Greenbank','358698','4587965215','25868',7,NULL,'(360) 555-0100','(360) 555-0101','http://www.contoso.com','Unit 2','2934 Night Road','98253',NULL,'PO Box 1012','Jolimont','98253',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(9,'Nod Publishers',2,37,38,10,10346,10346,'GL08029802','Nod Publishers','Woodgrove Bank Elizabeth City','365985','2021545878','48758',7,'Marcos is not in on Mondays','(252) 555-0100','(252) 555-0101','http://www.nodpublishers.com','Level 1','389 King Street','27906',NULL,'PO Box 3390','Anderson','27906',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(10,'Northwind Electric Cars',3,39,40,8,7899,7899,'ML0300202','Northwind Electric Cars','Woodgrove Bank Crandon Lakes','325447','3258786987','36214',30,NULL,'(201) 555-0105','(201) 555-0104','http://www.northwindelectriccars.com','','440 New Road','07860',NULL,'PO Box 30920','Arlington','07860',1,'2013-01-01 00:00:00.000000','2013-01-01 00:05:00.000000'),(14,'A Datum Corporation___NEW',2,21,22,7,38171,38171,'AA20384','A Datum Corporation','Woodgrove Bank Zionsville','356981','8575824136','25986',14,NULL,'(847) 555-0100','(847) 555-0101','http://www.adatum.com','Suite 10','183838 Southwest Boulevard','46077',_binary '\0\0\0\0\0\0\01\'h�ÐU�\�_7��C@','PO Box 1039','Surrey','46077',1,'2020-03-24 12:20:55.910870','2020-03-24 12:20:55.926879'),(16,'Consolidated Messenger___NEW',6,25,26,NULL,30378,30378,'209340283','Consolidated Messenger','Woodgrove Bank San Francisco','354269','3254872158','45698',30,NULL,'(415) 555-0100','(415) 555-0101','http://www.consolidatedmessenger.com','','894 Market Day Street','94101',_binary '\0\0\0\0\0\0\0\���ך^�R�\�\�0\�B@','PO Box 1014','West Mont','94101',1,'2020-03-24 12:20:55.910870','2020-03-24 12:20:55.937700'),(23,'My Supplier 5',8,37,38,9,30378,30378,'ML0300256','My Supplier 5','My Bank Branch 1','322784','3000487999','25896',30,'Just comment','(406) 446-0505','(406) 446-0506','http://www.msplr5.com','Level 13',NULL,'765239',NULL,'PO Box 115','PO Box 116','44785',1,'2020-03-25 16:30:14.380473','2020-03-25 16:30:14.392472'),(22,'My Supplier 4',7,35,36,8,17277,17277,NULL,'My Supplier 4','My Bank Branch 3','966580','3021578844','15987',30,NULL,'(406) 103-1087','(406) 103-1088','http://www.msplr4.com','Level 53',NULL,'765239',NULL,'PO Box 36974',NULL,'36695',1,'2020-03-25 16:30:14.380473','2020-03-25 16:30:14.402520');
/*!40000 ALTER TABLE `purchasing_suppliers_archive` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 11:38:02
