-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: wideworldimporters
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sales_specialdeals`
--

DROP TABLE IF EXISTS `sales_specialdeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_specialdeals` (
  `SpecialDealID` int NOT NULL,
  `StockItemID` int DEFAULT NULL,
  `CustomerID` int DEFAULT NULL,
  `BuyingGroupID` int DEFAULT NULL,
  `CustomerCategoryID` int DEFAULT NULL,
  `StockGroupID` int DEFAULT NULL,
  `DealDescription` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `DiscountAmount` decimal(18,2) DEFAULT NULL,
  `DiscountPercentage` decimal(18,3) DEFAULT NULL,
  `UnitPrice` decimal(18,2) DEFAULT NULL,
  `LastEditedBy` int NOT NULL,
  `LastEditedWhen` datetime(6) NOT NULL,
  PRIMARY KEY (`SpecialDealID`),
  KEY `FK_Sales_SpecialDeals_StockItemID` (`StockItemID`),
  KEY `FK_Sales_SpecialDeals_CustomerID` (`CustomerID`),
  KEY `FK_Sales_SpecialDeals_BuyingGroupID` (`BuyingGroupID`),
  KEY `FK_Sales_SpecialDeals_CustomerCategoryID` (`CustomerCategoryID`),
  KEY `FK_Sales_SpecialDeals_StockGroupID` (`StockGroupID`),
  KEY `FK_Sales_SpecialDeals_Application_People` (`LastEditedBy`),
  CONSTRAINT `FK_Sales_SpecialDeals_Application_People` FOREIGN KEY (`LastEditedBy`) REFERENCES `application_people` (`PersonID`),
  CONSTRAINT `FK_Sales_SpecialDeals_BuyingGroupID_Sales_BuyingGroups` FOREIGN KEY (`BuyingGroupID`) REFERENCES `sales_buyinggroups` (`BuyingGroupID`),
  CONSTRAINT `FK_Sales_SpecialDeals_CustomerCategoryID_Sales_CustomerCategor27` FOREIGN KEY (`CustomerCategoryID`) REFERENCES `sales_customercategories` (`CustomerCategoryID`),
  CONSTRAINT `FK_Sales_SpecialDeals_CustomerID_Sales_Customers` FOREIGN KEY (`CustomerID`) REFERENCES `sales_customers` (`CustomerID`),
  CONSTRAINT `FK_Sales_SpecialDeals_StockGroupID_Warehouse_StockGroups` FOREIGN KEY (`StockGroupID`) REFERENCES `warehouse_stockgroups` (`StockGroupID`),
  CONSTRAINT `FK_Sales_SpecialDeals_StockItemID_Warehouse_StockItems` FOREIGN KEY (`StockItemID`) REFERENCES `warehouse_stockitems` (`StockItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_specialdeals`
--

LOCK TABLES `sales_specialdeals` WRITE;
/*!40000 ALTER TABLE `sales_specialdeals` DISABLE KEYS */;
INSERT INTO `sales_specialdeals` VALUES (1,NULL,NULL,2,NULL,7,'10% 1st qtr USB Wingtip','2016-01-01','2016-03-31',NULL,10.000,NULL,2,'2015-12-31 16:00:00.000000'),(2,NULL,NULL,1,NULL,7,'15% 2nd qtr USB Tailspin','2016-04-01','2016-06-30',NULL,15.000,NULL,2,'2015-12-31 16:00:00.000000');
/*!40000 ALTER TABLE `sales_specialdeals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 11:38:04
